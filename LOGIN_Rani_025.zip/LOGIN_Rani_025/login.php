<?php

include "connection.php";
    session_start();

    if(isset($_POST["login"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        $result = mysqli_query($conn, "SELECT * from admin WHERE username='$username'");

        if(mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);

            if($password == $row["password"]) {
                $_SESSION["login"] = true;
                echo "<script>
                        alert('LOGIN SUCCESS');
                        document.location.href = 'template.php'; 
                </script>";

                exit;
            }
        }
        $error = true;
        }
?>


    












<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>

    <style type="text/css">
		    #form-login{
                border-style: solid;
                border-color: black;
                width: 400px;
                height: 200px;
                margin-left: 450px;
                margin-top: 200px; 
                padding: 10px;
		}
	</style>
</head>
<body>
    <div id='form-login' align="center">
        <form method="post" action="login.php">
            <center>
                <h1 align="bottom">LOGIN</h1>
    <table>

        <tr>
            <td>Username</td>
            <td>:</td>
            <td><input type="text" name="username" placeholder="masukkan username" required="" autofocus=""></td>
        </tr>

        <tr>
            <td>Password</td>
            <td>:</td>
            <td><input type="password" name="password" placeholder="masukkan password"required="" autofocus=""></td>
        </tr>

         <tr>
            <td colspan="3"><button input type="submit" name="login">LOGIN</td></button>
        </tr>

    </table>
   
        </center>
    </form>
</body>
</html>

    
    

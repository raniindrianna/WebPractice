<?php

echo "INI BERITA";

?>
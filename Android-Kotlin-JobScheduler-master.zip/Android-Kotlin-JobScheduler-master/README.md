# Android Kotlin JobScheduler example
Android sample project where JobSchedule is implemented with Kotlin

### Versions:
Android studio: 3.5
Kotlin: 1.3.50

Dev: David Cruz
web: https://www.davidcruz.co.uk
email: me@davidcruz.co.uk

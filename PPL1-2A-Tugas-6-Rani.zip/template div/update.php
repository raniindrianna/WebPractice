<?php
require 'functions.php';
$conn = mysqli_connect("localhost", "root", "", "db_akademis");

if (isset($_GET["nim"])) {
    $nim = $_GET["nim"];
}

if (isset($_POST["save"])) {
    $query = update($nim);
    mysqli_query($conn, $query);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .form-add {
            padding-left: 140px;
            padding-right: 140px;
            padding-top: 20px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1 align="center">UPDATE MAHASISWA</h1>
        <div class="form-update"></div>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">

                <label class="control-label col-sm-2" for="nim">NIM</label>
                <div class="col-sm-10"></div>
                <input type="text" name="nim" id="nim" class="form-control" disabled autocomplete="off" required value=<?= $nim ?>>


                <div class="form-group">
                    <label class="control-label col-sm-2" for="nama">NAMA</label>
                    <div class="col-sm-10"></div>
                    <input type="text" name="nama" id="nama" class="form-control" autocomplete="off">
                </div>

                <div class="form-group">
                    <label class="control-label col-sm-2" for="umur">UMUR:</label>
                    <div class="col-sm-10"></div>
                    <input type="text" name="umur" id="umur" class="form-control" autocomplete="off">
                </div>


                <div class="form-group">
                    <label class="control-label col-sm-2" for="pict">FOTO:</label>
                    <div class="col-sm-10"></div>
                    <input type="file" name="pict" id="pict" class="form-control">
                </div>
                <br>

                <button class="btn btn-primary" type="submit" value="submit" name="save">SAVE</button>
                <a href="template.php?page=pengembanganDataSiswa.php" class="btn btn-info">BACK</a>
                </table>
        </form>
    </div>
</body>

</html>
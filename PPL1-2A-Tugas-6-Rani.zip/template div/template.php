<?php
session_start();
if (!isset($_SESSION["login"])) {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE HTML>
<html>

<head>
    <style>
        .header {
            border-style: double;
        }

        .nav {
            background-color: navajowhite;
            border-style: double;
        }

        .nav a {
            margin: 10px;
        }

        .content {
            height: 600px;
            border-style: double;
            /* margin-left:310px; */
        }

        .sidenav li {
            margin: 5px;
        }

        .footer {
            border-style: double;
            /* height : 150px; */
        }
    </style>

    <title>Template</title>

</head>

<body>
    <div class="header">
        <h1 align="center">HEADER</h1>
    </div>


    <div class="nav">
        <a href="template.php?page=home.php">HOME</a>
        <a href="template.php?page=berita.php">BERITA</a>
        <a href="template.php?page=pengembanganDataSiswa.php">DATA SISWA</a>
        <a href="template.php?page=insert.php">INSERT MAHASISWA</a>
        <a href="logout.php">LOGOUT</a>
    </div>

    <div class="content">
        <?php
        if (!empty($_GET['page'])) {
            include $_GET['page'];
        } else {
            include "home.php";
        }
        ?>


    </div>

    <div class="footer">

        <h1 align="center">FOOTER</h1>
    </div>
</body>

</html>